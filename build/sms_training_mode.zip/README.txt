Sailor Moon S — modern training mode (pure Mesen 2 Lua, no ROM changes)

Quick start: read docs/training_install.md, then docs/training_usage.md.
If you extracted this outside the original repo, run ./fixpaths.sh first.
Main script: tools/training.lua (run it in Mesen's Script Window during a VS match).
