#!/bin/bash
# fixpaths.sh — repoint the training scripts' absolute ROOT to this directory.
# Run from the extract directory:  ./fixpaths.sh
set -e
HERE="$(cd "$(dirname "$0")" && pwd)"
OLD="/Users/koneko/Developer/SailorMoonS"
for f in tools/training.lua tools/training_test.lua; do
  sed -i.bak "s|$OLD|$HERE|g" "$HERE/$f" && rm -f "$HERE/$f.bak"
done
echo "paths repointed to $HERE"
echo "note: headless self-tests also need a Mesen binary at tools/Mesen.app (edit tools/run.sh otherwise)"
